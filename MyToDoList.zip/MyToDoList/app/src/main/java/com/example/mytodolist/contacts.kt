package com.example.mytodolist

class Message(val id: String, val name: String, val message:String)